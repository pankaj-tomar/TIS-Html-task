$(window).load(function() {
  $('.flexslider').flexslider({
    animation: "slide"
  });
  $( ".flex-control-nav, .flex-direction-nav" ).wrap( "<div class='cont-wrap'></div>" );
  $( ".cont-wrap" ).wrap( "<div class='wrapper-cont'></div>" );
  
});






  
